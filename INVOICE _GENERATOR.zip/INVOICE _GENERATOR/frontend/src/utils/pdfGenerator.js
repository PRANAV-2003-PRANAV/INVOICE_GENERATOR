import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

export const generateInvoicePDF = (invoice) => {
  try {
    const doc = new jsPDF();
    const pageWidth = doc.internal.pageSize.getWidth();

    // Branding
    doc.setFontSize(24);
    doc.setFont('helvetica', 'bold');
    doc.text('INVOICE', 14, 22);
    

    // Invoice Details
    doc.setFontSize(11);
    doc.text(`Invoice Number: ${invoice.invoiceNumber || 'N/A'}`, 14, 40);
    doc.text(`Invoice Date: ${invoice.date ? new Date(invoice.date).toLocaleDateString() : 'N/A'}`, 14, 46);
    
    const dueDate = invoice.date ? new Date(invoice.date) : new Date();
    dueDate.setDate(dueDate.getDate() + 15);
    doc.text(`Due Date: ${dueDate.toLocaleDateString()}`, 14, 52);

    // Customer Info
    doc.setFont('helvetica', 'bold');
    doc.text('Billed To:', 14, 65);
    doc.setFont('helvetica', 'normal');
    doc.text(`Customer Name: ${invoice.customerDetails?.name || 'N/A'}`, 14, 71);
    doc.text(`Phone Number: ${invoice.customerDetails?.phone || 'N/A'}`, 14, 77);
    doc.text(`Email ID: ${invoice.customerDetails?.email || 'N/A'}`, 14, 83);
    doc.text(`Billing Address: ${invoice.customerDetails?.address || 'N/A'}`, 14, 89);

    // Line Items Table
    const tableData = (invoice.lineItems || []).map(item => {
      const discountObj = item.discount || {};
      const discountType = discountObj.type || item.discountType || 'percent';
      const discountValue = discountObj.value !== undefined ? discountObj.value : (item.discountValue || 0);

      return [
        item.itemName || 'N/A',
        item.variant || '-',
        item.quantity || 0,
        `Rs. ${(item.price || 0).toFixed(2)}`,
        `${item.gstPercent || 0}%`,
        discountType === 'percent' ? `${discountValue}%` : `Rs. ${discountValue.toFixed(2)}`,
        `Rs. ${(item.rowTotal || 0).toFixed(2)}`
      ];
    });

    autoTable(doc, {
      startY: 100,
      head: [['Item Name', 'Variant / Description', 'Qty', 'Base Price', 'GST %', 'Discount', 'Row Total']],
      body: tableData,
      theme: 'grid',
      headStyles: { fillColor: [79, 70, 225], textColor: 255 },
      styles: { fontSize: 9, cellPadding: 4 },
      columnStyles: {
        0: { cellWidth: 40 },
        6: { halign: 'right' }
      }
    });

    // Summary
    const finalY = (doc.lastAutoTable?.finalY || 100) + 10;
    doc.setFontSize(10);
    doc.text('Calculation Summary', 14, finalY);
    doc.line(14, finalY + 2, 60, finalY + 2);

    doc.text(`Subtotal: Rs. ${(invoice.subtotal || 0).toFixed(2)}`, 14, finalY + 10);
    doc.text(`Total Discount: - Rs. ${(invoice.totalDiscount || 0).toFixed(2)}`, 14, finalY + 16);
    doc.text(`Total GST: + Rs. ${(invoice.totalGst || 0).toFixed(2)}`, 14, finalY + 22);
    
    doc.setFontSize(12);
    doc.setFont('helvetica', 'bold');
    doc.text(`GRAND TOTAL: Rs. ${(invoice.grandTotal || 0).toFixed(2)}`, 14, finalY + 30);

    // T&C - placed directly below summary
    const tcY = finalY + 44;
    doc.setFontSize(9);
    doc.setFont('helvetica', 'bold');
    doc.text('Terms & Conditions', 14, tcY);
    doc.setFont('helvetica', 'normal');
    doc.text('1. Payment is due within 15 days of the invoice date.', 14, tcY + 6);
    doc.text('2. A late fee of 2% per month will be applied to overdue balances.', 14, tcY + 11);
    doc.text('3. All disputes are subject to local jurisdiction only.', 14, tcY + 16);
    doc.text('4. Thank you for your business!', 14, tcY + 21);

    doc.save(`${invoice.invoiceNumber || 'invoice'}.pdf`);
  } catch (error) {
    console.error('PDF Generation Error:', error);
  }
};

