import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-hot-toast';

const API_BASE = 'http://localhost:5000/api/items';

const emptyVariant = () => ({ name: '', price: '' });

const ItemManager = () => {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedItems, setSelectedItems] = useState([]);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    gstPercent: 18,
    variants: [emptyVariant()]
  });

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const { data } = await axios.get(API_BASE);
      setItems(data);
    } catch (err) {
      toast.error('Failed to fetch items');
    } finally {
      setLoading(false);
    }
  };

  /* ── Selection Helpers ── */
  const toggleSelect = (id) => {
    setSelectedItems(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedItems.length === items.length) {
      setSelectedItems([]);
    } else {
      setSelectedItems(items.map(i => i._id));
    }
  };

  /* ── Delete Actions ── */
  const deleteItem = async (id) => {
    if (!window.confirm('Are you sure you want to delete this item?')) return;
    try {
      await axios.delete(`${API_BASE}/${id}`);
      toast.success('Item deleted');
      fetchItems();
      setSelectedItems(prev => prev.filter(item => item !== id));
    } catch (err) {
      toast.error('Failed to delete item');
    }
  };

  const deleteSelected = async () => {
    if (selectedItems.length === 0) return;
    if (!window.confirm(`Are you sure you want to delete ${selectedItems.length} items?`)) return;
    
    try {
      await Promise.all(selectedItems.map(id => axios.delete(`${API_BASE}/${id}`)));
      toast.success(`${selectedItems.length} items deleted`);
      setSelectedItems([]);
      fetchItems();
    } catch (err) {
      toast.error('Failed to delete some items');
    }
  };

  /* ── variant helpers ── */
  const updateVariant = (index, field, value) => {
    const updated = formData.variants.map((v, i) =>
      i === index ? { ...v, [field]: value } : v
    );
    setFormData({ ...formData, variants: updated });
  };

  const addVariant = () =>
    setFormData({ ...formData, variants: [...formData.variants, emptyVariant()] });

  const removeVariant = (index) => {
    if (formData.variants.length === 1) return;
    setFormData({
      ...formData,
      variants: formData.variants.filter((_, i) => i !== index)
    });
  };

  /* ── submit ── */
  const handleSubmit = async (e) => {
    e.preventDefault();

    // validate variants
    for (const v of formData.variants) {
      if (!v.name.trim()) return toast.error('Each variant must have a name');
      if (v.price === '' || isNaN(parseFloat(v.price))) return toast.error('Each variant must have a valid price');
    }

    try {
      const payload = {
        name: formData.name,
        description: formData.description,
        gstPercent: formData.gstPercent,
        variants: formData.variants.map(v => ({
          name: v.name.trim(),
          price: parseFloat(v.price)
        })),
        basePrice: parseFloat(formData.variants[0].price) || 0
      };
      await axios.post(API_BASE, payload);
      toast.success('Item added successfully');
      setFormData({ name: '', description: '', gstPercent: 18, variants: [emptyVariant()] });
      setIsModalOpen(false);
      fetchItems();
    } catch (err) {
      toast.error('Failed to add item');
    }
  };

  const closeModal = () => {
    setFormData({ name: '', description: '', gstPercent: 18, variants: [emptyVariant()] });
    setIsModalOpen(false);
  };

  return (
    <div className="animate-fade" style={{ width: '100%', maxWidth: 'none' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '30px' }}>
        <div>
          <Link to="/" style={{ color: 'var(--primary)', fontSize: '14px', fontWeight: '600', marginBottom: '10px', display: 'block' }}>← Back to Dashboard</Link>
          <h1 style={{ fontSize: '32px', marginBottom: '8px' }}>Inventory Management</h1>
          <p style={{ color: 'var(--text-muted)' }}>Add and manage your products for invoicing.</p>
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button 
            className="btn btn-danger" 
            onClick={deleteSelected}
            disabled={selectedItems.length === 0}
            style={{ opacity: selectedItems.length === 0 ? 0.6 : 1, cursor: selectedItems.length === 0 ? 'not-allowed' : 'pointer' }}
          >
            <span>🗑</span> Delete Item 
            {selectedItems.length > 0 && ` (${selectedItems.length})`}
          </button>
          <button className="btn btn-primary" onClick={() => setIsModalOpen(true)}>
            <span>+</span> Add New Item
          </button>
        </div>
      </div>

      <div className="card">
        {loading ? (
          <p>Loading items...</p>
        ) : (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th style={{ width: '40px' }}>
                    <input 
                      type="checkbox" 
                      onChange={toggleSelectAll}
                      checked={items.length > 0 && selectedItems.length === items.length}
                      style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                    />
                  </th>
                  <th style={{ width: '280px' }}>Item Name</th>
                  <th style={{ width: '320px' }}>Description</th>
                  <th style={{ minWidth: '300px' }}>Variants & Prices</th>
                  <th style={{ width: '100px' }}>Action</th>
                </tr>
              </thead>
              <tbody>
                {items.length > 0 ? items.map(item => (
                  <tr key={item._id} style={{ background: selectedItems.includes(item._id) ? 'rgba(79, 70, 229, 0.03)' : 'transparent' }}>
                    <td>
                      <input 
                        type="checkbox" 
                        checked={selectedItems.includes(item._id)}
                        onChange={() => toggleSelect(item._id)}
                        style={{ width: '18px', height: '18px', cursor: 'pointer' }}
                      />
                    </td>
                    <td style={{ fontWeight: '500' }}>{item.name}</td>
                    <td style={{ color: 'var(--text-muted)' }}>{item.description}</td>
                    <td>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
                        {item.variants.map((v, i) => (
                          <span key={i} style={{
                            background: 'rgba(79,70,229,0.1)',
                            color: 'var(--primary)',
                            padding: '3px 10px',
                            borderRadius: '20px',
                            fontSize: '12px',
                            fontWeight: '600',
                            border: '1px solid rgba(79,70,229,0.25)',
                            whiteSpace: 'nowrap'
                          }}>
                            {v.name} — ₹{(v.price || 0).toFixed(2)}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td>
                      <button 
                        onClick={() => deleteItem(item._id)}
                        style={{ background: 'none', color: 'var(--danger)', fontWeight: '600', padding: '4px' }}
                        title="Delete this item"
                      >
                        🗑
                      </button>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan="5" style={{ textAlign: 'center', padding: '40px' }}>No items found. Add your first item!</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ── Add Item Modal ── */}
      {isModalOpen && (
        <div style={{
          position: 'fixed', top: 0, left: 0, right: 0, bottom: 0,
          background: 'rgba(0,0,0,0.5)',
          display: 'flex', justifyContent: 'center', alignItems: 'center',
          zIndex: 1000, overflowY: 'auto', padding: '20px'
        }}>
          <div className="card animate-fade" style={{ width: '850px', maxHeight: '90vh', overflowY: 'auto', padding: '30px' }}>
            <h2 style={{ marginBottom: '20px' }}>Add New Item</h2>
            <form onSubmit={handleSubmit}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
                <div className="input-group" style={{ marginBottom: 0 }}>
                  <label>Item Name</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div className="input-group" style={{ marginBottom: 0 }}>
                  <label>GST Percentage (%)</label>
                  <select
                    value={formData.gstPercent}
                    onChange={(e) => setFormData({ ...formData, gstPercent: parseInt(e.target.value) })}
                    style={{ height: '46px' }}
                  >
                    <option value="0">0%</option>
                    <option value="5">5%</option>
                    <option value="12">12%</option>
                    <option value="18">18%</option>
                    <option value="28">28%</option>
                  </select>
                </div>
              </div>

              <div className="input-group" style={{ marginBottom: '20px' }}>
                <label>Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  style={{ height: '70px', resize: 'none' }}
                  placeholder="Optional product details..."
                />
              </div>

              {/* ── Variants Section ── */}
              <div style={{ marginBottom: '16px' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                  <label style={{ fontWeight: '600', fontSize: '14px' }}>Variants &amp; Prices</label>
                  <button
                    type="button"
                    onClick={addVariant}
                    style={{
                      background: 'rgba(79,70,229,0.1)',
                      color: 'var(--primary)',
                      border: '1px solid rgba(79,70,229,0.3)',
                      borderRadius: '8px',
                      padding: '4px 12px',
                      fontSize: '13px',
                      fontWeight: '600',
                      cursor: 'pointer'
                    }}
                  >
                    + Add Variant
                  </button>
                </div>

                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                  {formData.variants.map((variant, index) => (
                    <div key={index} style={{
                      display: 'flex',
                      gap: '10px',
                      alignItems: 'center',
                      background: '#f8fafc',
                      borderRadius: '10px',
                      padding: '10px 12px',
                      border: '1px solid var(--border)'
                    }}>
                      <div style={{ flex: 1 }}>
                        <label style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
                          Variant Name
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. Small, Large, Red"
                          value={variant.name}
                          onChange={(e) => updateVariant(index, 'name', e.target.value)}
                          style={{ marginBottom: 0 }}
                        />
                      </div>
                      <div style={{ width: '130px' }}>
                        <label style={{ fontSize: '11px', color: 'var(--text-muted)', marginBottom: '4px', display: 'block' }}>
                          Price (₹)
                        </label>
                        <input
                          type="number"
                          placeholder="0"
                          min="0"
                          value={variant.price}
                          onChange={(e) => updateVariant(index, 'price', e.target.value)}
                          style={{ marginBottom: 0 }}
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => removeVariant(index)}
                        disabled={formData.variants.length === 1}
                        style={{
                          background: 'none',
                          color: formData.variants.length === 1 ? '#ccc' : 'var(--danger)',
                          fontSize: '18px',
                          cursor: formData.variants.length === 1 ? 'not-allowed' : 'pointer',
                          marginTop: '18px',
                          border: 'none',
                          padding: '0 4px'
                        }}
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              <div style={{ display: 'flex', gap: '10px', justifyContent: 'flex-end', marginTop: '24px' }}>
                <button type="button" className="btn btn-outline" onClick={closeModal}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Item</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ItemManager;
