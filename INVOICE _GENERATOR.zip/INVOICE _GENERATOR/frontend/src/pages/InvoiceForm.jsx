import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { generateInvoicePDF } from '../utils/pdfGenerator';

const API_ITEMS = 'http://localhost:5000/api/items';
const API_INVOICES = 'http://localhost:5000/api/invoices';

const InvoiceForm = () => {
  const navigate = useNavigate();
  const [itemsList, setItemsList] = useState([]);
  const [customer, setCustomer] = useState({ name: '', phone: '', email: '', address: '' });
  const [lineItems, setLineItems] = useState([
    { item: '', itemName: '', variant: '', quantity: 1, price: 0, gstPercent: 18, discountType: 'percent', discountValue: 0, rowTotal: 0 }
  ]);
  const [summary, setSummary] = useState({ subtotal: 0, totalGst: 0, totalDiscount: 0, grandTotal: 0 });

  useEffect(() => {
    fetchItems();
  }, []);

  const fetchItems = async () => {
    try {
      const { data } = await axios.get(API_ITEMS);
      setItemsList(data);
    } catch (err) {
      toast.error('Failed to fetch items');
    }
  };

  const recalculate = (rows) => {
    let subtotal = 0;
    let totalGst = 0;
    let totalDiscount = 0;

    const updatedRows = rows.map(row => {
      const baseTotal = (row.price || 0) * (row.quantity || 0);
      let dsAmount = 0;
      if (row.discountType === 'percent' || row.discount?.type === 'percent') {
        const val = row.discountValue !== undefined ? row.discountValue : (row.discount?.value || 0);
        dsAmount = (baseTotal * val) / 100;
      } else {
        dsAmount = row.discountValue !== undefined ? row.discountValue : (row.discount?.value || 0);
      }

      const taxableAmount = baseTotal - dsAmount;
      const gstAmount = (taxableAmount * (row.gstPercent || 0)) / 100;
      const rowTotal = taxableAmount + gstAmount;

      subtotal += baseTotal;
      totalGst += gstAmount;
      totalDiscount += dsAmount;

      return { ...row, rowTotal };
    });

    setLineItems(updatedRows);
    setSummary({
      subtotal,
      totalGst,
      totalDiscount,
      grandTotal: subtotal - totalDiscount + totalGst
    });
  };

  const handleItemChange = (index, itemId) => {
    const selectedItem = itemsList.find(i => i._id === itemId);
    if (!selectedItem) return;

    const firstVariant = selectedItem.variants[0] || null;
    const newLineItems = [...lineItems];
    newLineItems[index] = {
      ...newLineItems[index],
      item: itemId,
      itemName: selectedItem.name,
      gstPercent: selectedItem.gstPercent || 0,
      variant: firstVariant ? firstVariant.name : '',
      price: firstVariant ? firstVariant.price : 0
    };
    recalculate(newLineItems);
  };

  const handleVariantChange = (index, variantName) => {
    const row = lineItems[index];
    const selectedItem = itemsList.find(i => i._id === row.item);
    const variantObj = selectedItem?.variants.find(v => v.name === variantName);
    const newLineItems = lineItems.map((item, i) =>
      i === index
        ? { ...item, variant: variantName, price: variantObj ? variantObj.price : item.price }
        : item
    );
    recalculate(newLineItems);
  };

  const updateLineItem = (index, field, value) => {
    const newLineItems = lineItems.map((item, i) => 
      i === index ? { ...item, [field]: value } : item
    );
    recalculate(newLineItems);
  };

  const addRow = () => {
    const newItems = [...lineItems, { item: '', itemName: '', variant: '', quantity: 1, price: 0, gstPercent: 18, discountType: 'percent', discountValue: 0, rowTotal: 0 }];
    setLineItems(newItems);
  };

  const removeRow = (index) => {
    if (lineItems.length === 1) return;
    const newItems = lineItems.filter((_, i) => i !== index);
    recalculate(newItems);
  };

  const saveInvoice = async () => {
    if (!customer.name) return toast.error('Customer name is required');
    try {
      const payload = {
        customerDetails: customer,
        lineItems: lineItems.map(item => ({
          ...item,
          discount: {
            type: item.discountType || 'percent',
            value: item.discountValue || 0
          }
        })),
        ...summary,
        date: new Date()
      };
      const { data } = await axios.post(API_INVOICES, payload);
      toast.success('Invoice saved successfully');
      generateInvoicePDF(data);
      navigate('/');
    } catch (err) {
      toast.error('Failed to save invoice');
    }
  };

  return (
    <div className="animate-fade">
      <div style={{ marginBottom: '30px' }}>
        <h1 style={{ fontSize: '32px', marginBottom: '8px' }}>Create New Invoice</h1>
      </div>

      <div className="card" style={{ marginBottom: '24px' }}>
        <h3 style={{ marginBottom: '16px' }}>Customer Details</h3>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px' }}>
          <div className="input-group">
            <label>Full Name</label>
            <input type="text" value={customer.name} onChange={e => setCustomer({...customer, name: e.target.value})} />
          </div>
          <div className="input-group">
            <label>Phone Number</label>
            <input type="text" value={customer.phone} onChange={e => setCustomer({...customer, phone: e.target.value})} />
          </div>
          <div className="input-group">
            <label>Email ID</label>
            <input type="email" value={customer.email} onChange={e => setCustomer({...customer, email: e.target.value})} />
          </div>
          <div className="input-group">
            <label>Billing Address</label>
            <input type="text" value={customer.address} onChange={e => setCustomer({...customer, address: e.target.value})} />
          </div>
        </div>
      </div>

      <div className="card" style={{ marginBottom: '24px' }}>
        <h3 style={{ marginBottom: '16px' }}>Line Items</h3>
        <div className="table-container">
          <table>
            <thead>
              <tr>
                <th style={{ width: '35%' }}>Item</th>
                <th style={{ width: '15%' }}>Variant</th>
                <th>Qty</th>
                <th>Price (₹)</th>
                <th>GST %</th>
                <th>Discount</th>
                <th>Total (₹)</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {lineItems.map((row, index) => (
                <tr key={index}>
                  <td>
                    <select value={row.item} onChange={e => handleItemChange(index, e.target.value)}>
                      <option value="">Select Item</option>
                      {itemsList.map(item => (
                        <option key={item._id} value={item._id}>{item.name}</option>
                      ))}
                    </select>
                  </td>
                  <td>
                    <select value={row.variant} onChange={e => handleVariantChange(index, e.target.value)}>
                        {itemsList.find(i => i._id === row.item)?.variants.map(v => (
                            <option key={v.name} value={v.name}>{v.name}</option>
                        ))}
                    </select>
                  </td>
                  <td>
                    <input
                      type="number"
                      value={row.quantity === 0 ? '' : row.quantity}
                      placeholder="1"
                      min="1"
                      onChange={e => updateLineItem(index, 'quantity', parseInt(e.target.value) || 0)}
                      style={{ width: '65px' }}
                    />
                  </td>
                  <td>
                    <input 
                      type="number" 
                      value={row.price} 
                      readOnly 
                      style={{ width: '100px', backgroundColor: '#f1f5f9', cursor: 'not-allowed' }} 
                    />
                  </td>
                  <td>
                    <select
                      value={row.gstPercent}
                      onChange={e => updateLineItem(index, 'gstPercent', parseInt(e.target.value))}
                      style={{
                        width: '75px',
                        fontWeight: '600',
                        color: 'var(--primary)',
                        background: 'rgba(79, 70, 229, 0.08)',
                        border: '1.5px solid rgba(79, 70, 229, 0.3)',
                        borderRadius: '8px',
                        padding: '8px 6px',
                        textAlign: 'center',
                        cursor: 'pointer'
                      }}
                    >
                      <option value="0">0%</option>
                      <option value="5">5%</option>
                      <option value="12">12%</option>
                      <option value="18">18%</option>
                      <option value="28">28%</option>
                    </select>
                  </td>

                  <td>
                    <div style={{ display: 'flex', gap: '4px', alignItems: 'center' }}>
                        <input
                          type="number"
                          value={row.discountValue === 0 ? '' : row.discountValue}
                          placeholder="0"
                          onChange={e => updateLineItem(index, 'discountValue', parseFloat(e.target.value) || 0)}
                          style={{ width: '70px' }}
                        />
                        <select
                          value={row.discountType}
                          onChange={e => updateLineItem(index, 'discountType', e.target.value)}
                          style={{ width: '55px', padding: '12px 4px' }}
                        >
                            <option value="percent">%</option>
                            <option value="absolute">₹</option>
                        </select>
                    </div>
                  </td>
                  <td style={{ fontWeight: '600' }}>₹{row.rowTotal.toFixed(2)}</td>
                  <td>
                    <button onClick={() => removeRow(index)} style={{ color: 'var(--danger)', background: 'none' }}>✕</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <button className="btn btn-outline" onClick={addRow} style={{ marginTop: '16px' }}>+ Add Row</button>
      </div>

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <div className="card" style={{ width: '350px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Subtotal:</span>
            <span>₹{summary.subtotal.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Total Discount:</span>
            <span style={{ color: 'var(--danger)' }}>- ₹{summary.totalDiscount.toFixed(2)}</span>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '12px' }}>
            <span style={{ color: 'var(--text-muted)' }}>Total GST:</span>
            <span>+ ₹{summary.totalGst.toFixed(2)}</span>
          </div>
          <hr style={{ margin: '12px 0', border: 'none', borderTop: '1px solid var(--border)' }} />
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: '700', fontSize: '18px' }}>
            <span>Grand Total:</span>
            <span style={{ color: 'var(--primary)' }}>₹{summary.grandTotal.toFixed(2)}</span>
          </div>
          <button 
            className="btn btn-primary" 
            style={{ width: '100%', marginTop: '24px', justifyContent: 'center' }}
            onClick={saveInvoice}
          >
            Save Invoice and Finish
          </button>
        </div>
      </div>
    </div>
  );
};

export default InvoiceForm;
