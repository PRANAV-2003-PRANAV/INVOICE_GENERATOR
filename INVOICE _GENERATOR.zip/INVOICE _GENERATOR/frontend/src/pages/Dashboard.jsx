import { useState, useEffect } from 'react';
import axios from 'axios';
import { toast } from 'react-hot-toast';
import { generateInvoicePDF } from '../utils/pdfGenerator';

const API_INVOICES = 'http://localhost:5000/api/invoices';

const Dashboard = () => {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInvoices();
  }, []);

  const fetchInvoices = async () => {
    try {
      const { data } = await axios.get(API_INVOICES);
      setInvoices(data);
    } catch (err) {
      toast.error('Failed to fetch invoices');
    } finally {
      setLoading(false);
    }
  };

  const totals = {
    count: invoices.length,
    revenue: invoices.reduce((acc, inv) => acc + inv.grandTotal, 0)
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      await axios.patch(`${API_INVOICES}/${id}/status`, { status: newStatus });
      setInvoices(invoices.map(inv => inv._id === id ? { ...inv, status: newStatus } : inv));
      toast.success('Status updated successfully');
    } catch (err) {
      toast.error('Failed to update status');
    }
  };

  return (
    <div className="animate-fade">
      <div style={{ marginBottom: '40px' }}>
        <h1 style={{ fontSize: '32px', marginBottom: '8px' }}>Welcome back!</h1>
        <p style={{ color: 'var(--text-muted)' }}>Here is what's happening with your invoices today.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px', marginBottom: '40px' }}>
        <div className="card glass">
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '8px' }}>Total Invoices</p>
          <h2 style={{ fontSize: '28px' }}>{totals.count}</h2>
        </div>
        <div className="card glass">
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '8px' }}>Total Revenue</p>
          <h2 style={{ fontSize: '28px' }}>₹{totals.revenue.toLocaleString()}</h2>
        </div>
        <div className="card glass" style={{ borderLeft: '4px solid var(--secondary)' }}>
          <p style={{ fontSize: '14px', color: 'var(--text-muted)', marginBottom: '8px' }}>Pending Payments</p>
          <h2 style={{ fontSize: '28px' }}>{invoices.filter(i => i.status === 'Pending').length}</h2>
        </div>
      </div>

      <div className="card">
        <h3 style={{ marginBottom: '20px' }}>Recent Invoices</h3>
        {loading ? (
          <p>Loading history...</p>
        ) : (
          <div className="table-container">
            <table>
              <thead>
                <tr>
                  <th>Invoice #</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {invoices.length > 0 ? invoices.map(inv => (
                  <tr key={inv._id}>
                    <td style={{ fontWeight: '600', color: 'var(--primary)' }}>{inv.invoiceNumber}</td>
                    <td>
                      <div>{inv.customerDetails.name}</div>
                      <div style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{inv.customerDetails.phone}</div>
                    </td>
                    <td>{new Date(inv.date).toLocaleDateString()}</td>
                    <td style={{ fontWeight: '600' }}>₹{inv.grandTotal.toFixed(2)}</td>
                    <td>
                      <select 
                        value={inv.status} 
                        onChange={(e) => handleStatusChange(inv._id, e.target.value)}
                        style={{
                          padding: '4px 10px',
                          borderRadius: '20px',
                          fontSize: '12px',
                          fontWeight: '600',
                          background: inv.status === 'Paid' ? '#dcfce7' : inv.status === 'Unpaid' ? '#fee2e2' : '#fef9c3',
                          color: inv.status === 'Paid' ? '#166534' : inv.status === 'Unpaid' ? '#991b1b' : '#854d0e',
                          border: 'none',
                          cursor: 'pointer',
                          outline: 'none',
                          appearance: 'none',
                          textAlign: 'center'
                        }}
                      >
                        <option value="Pending">Pending</option>
                        <option value="Paid">Paid</option>
                        <option value="Unpaid">Unpaid</option>
                      </select>
                    </td>
                    <td>
                      <button 
                        className="btn btn-outline" 
                        style={{ padding: '6px 12px', fontSize: '12px' }}
                        onClick={() => generateInvoicePDF(inv)}
                      >
                        Download PDF
                      </button>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan="6" style={{ textAlign: 'center', padding: '40px' }}>No invoices yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
