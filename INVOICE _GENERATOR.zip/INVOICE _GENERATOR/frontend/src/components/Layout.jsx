import { useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';

const Layout = ({ children }) => {
  const location = useLocation();
  const isInventory = location.pathname === '/items';

  return (
    <div className="app-container" style={{ display: 'flex' }}>
      {!isInventory && <Sidebar />}
      <main style={{
        marginLeft: isInventory ? '0' : '260px',
        width: isInventory ? '100%' : 'calc(100% - 260px)',
        minHeight: '100vh',
        padding: isInventory ? '30px' : '40px',
        transition: 'all 0.3s ease'
      }}>
        {children}
      </main>
    </div>
  );
};

export default Layout;
