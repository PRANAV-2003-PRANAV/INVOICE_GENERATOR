import { Link, useLocation } from 'react-router-dom';

const Sidebar = () => {
  const location = useLocation();

  const links = [
    { name: 'Dashboard', path: '/', icon: '📊' },
    { name: 'Inventory', path: '/items', icon: '📦' },
    { name: 'Create Invoice', path: '/new-invoice', icon: '📝' },
  ];

  return (
    <div className="sidebar" style={{
      width: '260px',
      height: '100vh',
      background: '#ffffff',
      borderRight: '1px solid var(--border)',
      padding: '30px 20px',
      position: 'fixed',
      left: 0,
      top: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '30px',
      zIndex: 100
    }}>
      <div className="logo" style={{
        fontSize: '24px',
        fontWeight: '700',
        fontFamily: 'Outfit',
        color: 'var(--primary)',
        padding: '0 10px'
      }}>
        HealthyChef
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
        {links.map((link) => (
          <Link
            key={link.path}
            to={link.path}
            className={location.pathname === link.path ? 'active' : ''}
            style={{
              padding: '12px 16px',
              borderRadius: '10px',
              display: 'flex',
              alignItems: 'center',
              gap: '12px',
              fontSize: '15px',
              fontWeight: location.pathname === link.path ? '600' : '400',
              background: location.pathname === link.path ? '#4f46e50f' : 'transparent',
              color: location.pathname === link.path ? 'var(--primary)' : 'var(--text-muted)',
              transition: 'all 0.2s ease'
            }}
          >
            <span>{link.icon}</span>
            {link.name}
          </Link>
        ))}
      </nav>
    </div>
  );
};

export default Sidebar;
