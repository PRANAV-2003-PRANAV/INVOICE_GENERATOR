import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Layout from './components/Layout';
import Dashboard from './pages/Dashboard';
import ItemManager from './pages/ItemManager';
import InvoiceForm from './pages/InvoiceForm';

function App() {
  return (
    <Router>
      <Toaster position="top-right" />
      <Layout>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/items" element={<ItemManager />} />
          <Route path="/new-invoice" element={<InvoiceForm />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
