const mongoose = require('mongoose');

const InvoiceSchema = new mongoose.Schema({
    invoiceNumber: { type: String, required: true, unique: true },
    date: { type: Date, default: Date.now },
    dueDate: { type: Date },
    customerDetails: {
        name: { type: String, required: true },
        phone: { type: String },
        email: { type: String },
        address: { type: String }
    },
    lineItems: [{
        item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item' },
        itemName: { type: String }, // Storing name snapshot
        variant: { type: String },
        quantity: { type: Number, required: true },
        price: { type: Number, required: true },
        gstPercent: { type: Number, default: 0 },
        discount: {
            type: { type: String, enum: ['percent', 'absolute'], default: 'percent' },
            value: { type: Number, default: 0 }
        },
        rowTotal: { type: Number, required: true }
    }],
    subtotal: { type: Number, required: true },
    totalGst: { type: Number, required: true },
    totalDiscount: { type: Number, required: true },
    grandTotal: { type: Number, required: true },
    status: { type: String, enum: ['Paid', 'Unpaid', 'Pending'], default: 'Pending' }
}, { timestamps: true });

module.exports = mongoose.model('Invoice', InvoiceSchema);
