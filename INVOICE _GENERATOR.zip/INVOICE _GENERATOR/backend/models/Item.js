const mongoose = require('mongoose');

const VariantSchema = new mongoose.Schema({
    name: { type: String, required: true },
    price: { type: Number, required: true, default: 0 }
}, { _id: false });

const ItemSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String },
    variants: [VariantSchema],
    basePrice: { type: Number, default: 0 },
    gstPercent: { type: Number, default: 0 }
}, { timestamps: true });

module.exports = mongoose.model('Item', ItemSchema);
