const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');

// Get all invoices
router.get('/', async (req, res) => {
    try {
        const invoices = await Invoice.find().sort({ createdAt: -1 });
        res.json(invoices);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Create invoice
router.post('/', async (req, res) => {
    // Basic auto-generation of invoice number if not provided
    // Pattern: INV-YYYY-XXXX (where XXXX is the count + 1)
    let invoiceNumber = req.body.invoiceNumber;
    
    if (!invoiceNumber) {
        const year = new Date().getFullYear();
        const count = await Invoice.countDocuments({ 
            invoiceNumber: { $regex: `^INV-${year}` } 
        });
        invoiceNumber = `INV-${year}-${(count + 1).toString().padStart(4, '0')}`;
    }

    const invoice = new Invoice({
        invoiceNumber,
        date: req.body.date,
        dueDate: req.body.dueDate,
        customerDetails: req.body.customerDetails,
        lineItems: req.body.lineItems,
        subtotal: req.body.subtotal,
        totalGst: req.body.totalGst,
        totalDiscount: req.body.totalDiscount,
        grandTotal: req.body.grandTotal,
        status: req.body.status
    });

    try {
        const newInvoice = await invoice.save();
        res.status(201).json(newInvoice);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Get single invoice
router.get('/:id', async (req, res) => {
    try {
        const invoice = await Invoice.findById(req.params.id).populate('lineItems.item');
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        res.json(invoice);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Update invoice status
router.patch('/:id/status', async (req, res) => {
    try {
        const invoice = await Invoice.findByIdAndUpdate(
            req.params.id, 
            { status: req.body.status },
            { new: true }
        );
        if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
        res.json(invoice);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

module.exports = router;
